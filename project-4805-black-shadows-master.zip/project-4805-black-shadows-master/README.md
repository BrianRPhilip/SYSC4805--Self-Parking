# SYSC4805
Computer Systems Design Lab

**Black Shadows**

Group Members:

* Jonathan Arava (101007533)
* Viktor Dimitrov (101018187)
* Brian Ranjan Philip (101018883)
* Ezwad Rahman (100999305)


Link to final demo videos: https://drive.google.com/open?id=1nHAQpel1wwAWiOqrUvhHI5RxurX_tgyQ

Final working code in Final_Code_BlackShadows.ino file
